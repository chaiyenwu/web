#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 17:11:01 2018

@author: justinwu
"""
from urllib.error import HTTPError
from bs4 import BeautifulSoup
import sys
from urllib.request import urlopen


def getTitle(url):
    try:
        html = urlopen(url)
    except HTTPError as e:
        print(e)
        return None
    try:
        Obj = BeautifulSoup(html, "html.parser")
        title = Obj.body.a
    except AttributeError as e:
        return None
    return title

title = getTitle("http://www.google.com")
if title == None:
    print("找不到標題")
else:
    print(title)
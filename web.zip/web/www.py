#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 13:46:39 2018

@author: justinwu
"""

from bottle import  run, static_file,route

@route('/')
def www():
    return static_file('index.html', root='.')

run(host='localhost', port=9999)
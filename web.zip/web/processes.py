#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  2 22:02:43 2018

@author: chaiyenwu
"""

import multiprocessing
import os

def do_this(what):
    whoami(what)

def whoami(what):
    print("行程 %s says: %s" % (os.getpid(), what))

if __name__ == "__main__":
    whoami("主程式")
    for n in range(4):
        p = multiprocessing.Process(target=do_this,
          args=("do_this函數 %s" % n,))
        p.start()

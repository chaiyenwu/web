#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  2 16:37:33 2018

@author: chaiyenwu
"""

import urllib.request as ur
url='http://www.youtube.com'
conn=ur.urlopen(url)
print(conn)
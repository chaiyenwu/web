#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 20:34:40 2018

@author: justinwu
"""

import urllib.request as ur
url='http://www.google.com'
conn=ur.urlopen(url)
print(conn)
mydata=conn.read()
print(mydata)
print(conn.status)
print(conn.getheader('Content-Type'))
for key,value in conn.getheaders():
    print(key,value)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 15:33:26 2018

@author: justinwu
"""

#import antigravity
import webbrowser
url='http://tw.yahoo.com'
webbrowser.open(url)
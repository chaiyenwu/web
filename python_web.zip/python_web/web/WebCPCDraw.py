#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 21 18:59:16 2018

@author: justinwu
"""

import pymysql
import matplotlib.pyplot as pt

db=pymysql.connect("localhost","root","322739aa","HistoryGasPrice")
cursor=db.cursor()
sql="Select * from HistoryGasPrice"
try:
    listMonth=[]
    listGas92=[]
    listGas95=[]
    listGas98=[]
    listGasW=[]
    cursor.execute(sql)
    results=cursor.fetchall()
    for row in results:
        listMonth.append(row[0])
        listGas92.append(row[1])
        listGas95.append(row[2])
        listGas98.append(row[3])
        listGasW.append(row[4])
        print("%s,%6.2f,%6.2f,%6.2f,%6.2f"%\
              (row[0],row[1],row[2],row[3],row[4]))
except:
    print("Error:unable to fetch data")

db.close()
pt.figure(num=None,figsize=(3,3),dpi=168,facecolor='w',edgecolor='k')
pt.plot(listMonth,listGas92,lw=2,label='Gas92')
pt.plot(listMonth,listGas95,lw=2,label='Gas95')
pt.plot(listMonth,listGas98,lw=2,label='Gas98')
pt.plot(listMonth,listGasW,lw=2,label='GasW')
pt.xlabel('month')
pt.ylabel('dollars')
pt.legend()
pt.title("Python Data Science")
pt.show()


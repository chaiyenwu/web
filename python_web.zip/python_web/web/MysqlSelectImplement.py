#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 21 18:21:26 2018

@author: justinwu
"""

import pymysql

db=pymysql.connect("localhost","root","322739aa","HistoryGasPrice")
cursor=db.cursor()
sql="Select * from HistoryGasPrice"
try:
    cursor.execute(sql)
    results=cursor.fetchall()
    for row in results:
        print("%s,%6.2f,%6.2f,%6.2f,%6.2f"%\
              (row[0],row[1],row[2],row[3],row[4]))
except:
    print("Error:unable to fetch data")
    
db.close()



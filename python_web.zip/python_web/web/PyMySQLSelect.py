#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 21 15:47:38 2018

@author: justinwu
"""

import pymysql

db=pymysql.connect("localhost","root","322739aa","HistoryGasPrice")
cursor=db.cursor()
cursor.execute("SELECT VERSION()")
data=cursor.fetchone()
print("Database version:%s" % data)
db.close()
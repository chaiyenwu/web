#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 20 10:36:13 2018

@author: justinwu
"""

from urllib.error import HTTPError
from bs4 import BeautifulSoup
from urllib.request import urlopen
 
def getTitle(url):
     try:
         html=urlopen(url)
     except HTTPError as e:
         print(e)
         return None
     try:
         Obj=BeautifulSoup(html,"html.parser")
         title=Obj.body.a
     except AttributeError as e:
         print(e)
         return None
     return title
 
title=getTitle("http://www.google.com")
if title == None:
     print("找不到標題")
else:
     print(title)
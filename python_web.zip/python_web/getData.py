#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 17:11:01 2018

@author: justinwu
"""
from urllib.error import HTTPError
from bs4 import BeautifulSoup
import requests

def getData(url):
    try:
        html = requests.get(url).text
    except HTTPError as e:
        print(e)
        return None
    try:
        Obj = BeautifulSoup(html, "html.parser")
        myList = []
        myData = Obj.find_all('span',attrs={'id':'Showtd'})
        myRows=myData[0].find_all('tr')     
        for r in myRows:
            c=r.find_all('td')
            if (len(c[0].text)>0 and len(c[1].text)>0) and \
                   (len(c[2].text)>0 and len(c[3].text)>0)\
                                   and (len(c[4].text)>0):
                dataList=[]
                dataList.append(c[0].text)
                dataList.append(c[1].text)
                dataList.append(c[2].text)
                dataList.append(c[3].text)
                dataList.append(c[4].text)
                myList.append(dataList)
    except AttributeError as e:
        return None
    return myList

mList = getData('https://new.cpc.com.tw/division/mb/oil-more4.aspx')
i=0
for data in mList:
    if(i<500):
        i=i+1
        print(data)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan  7 12:24:27 2018

@author: justinwu
"""

#輸入sqlite3模組
import sqlite3
import os
#建立和myreviews.sqlite資料庫連接
conn=sqlite3.connect('myreviews.sqlite')
#使用資料庫指標cursor()
mycur=conn.cursor()
#使用資料庫指標mycur執行SQL指令
mycur.execute('select * from myreview')
#使用指標mycur的fetchall()函數來讀取所有資料
myresults=mycur.fetchall()
#關閉資料庫使用close()函數
conn.close()
print(myresults)


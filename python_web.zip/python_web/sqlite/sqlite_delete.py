#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan  7 20:11:01 2018

@author: justinwu
"""

#輸入sqlite3模組
import sqlite3
import os
#建立和myreviews.sqlite資料庫連接
conn=sqlite3.connect('myreview8.sqlite')
#使用資料庫指標cursor()
mycur=conn.cursor()
#使用資料庫指標mycur執行SQL指令
example3='I will like the movie.ok.'
#sql指令insert插入資料

mycur.execute("delete from myreview WHERE review='I will like the movie.ok.'")
conn.commit()
#關閉資料庫使用close()函數
conn.close()

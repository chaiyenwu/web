#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  9 11:58:28 2018

@author: justinwu
"""

import sqlite3
import os
conn=sqlite3.connect('myreview8.sqlite')
mycur=conn.cursor()
example3='I will like the movie.ok.'
mycur.execute("update myreview set sentiment =1 where review='I will like the movie.ok.'")
conn.commit()
conn.close()
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  9 11:43:40 2018

@author: justinwu
"""

import sqlite3
import os
conn=sqlite3.connect('myreview8.sqlite')
mycur=conn.cursor()
mycur.execute('create table myreview(review TEXT,sentiment integer,date text)')
example1='I would like the movie'
mycur.execute("insert into myreview(review,sentiment,date) values(?,?,DATETIME('now'))",(example1,1))
example2='I do not like the movie'
mycur.execute("insert into myreview(review,sentiment,date) values(?,?,DATETIME('now'))",(example2,0))
conn.commit()
conn.close()
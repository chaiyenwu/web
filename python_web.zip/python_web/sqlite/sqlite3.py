#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan  7 11:53:07 2018

@author: justinwu
"""
#輸入sqlite3模組
import sqlite3
import os
#建立和myreviews.sqlite資料庫連接
conn=sqlite3.connect('myreviews.sqlite')
#使用資料庫指標cursor()
mycur=conn.cursor()
#使用資料庫指標mycur執行SQL指令
mycur.execute('create table myreview(review TEXT,sentiment integer,date text)')
example1='I would like the movie'
mycur.execute("insert into myreview(review,sentiment,date) values (?,?,DATETIME('now'))",(example1,1)) 
example2='I do not like the movie'
mycur.execute("insert into myreview(review,sentiment,date) values (?,?,DATETIME('now'))",(example2,0))
#送出指令並交由資料庫執行使用commit
conn.commit()
#關閉資料庫使用close()函數
conn.close()
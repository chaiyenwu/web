#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  9 11:53:55 2018

@author: justinwu
"""

import sqlite3
conn=sqlite3.connect('ChineseOil.sqlite')
mycur=conn.cursor()
example='2018/02/02'
example1=27.0
example2=28.5
example3=30.5
example4=24.9

sql="insert into HistoryGasPrice values('{}',{},{},{},{});".format(example\
                ,example1,example2,example3,example4)
mycur.execute(sql)
conn.commit()
conn.close()


#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  9 11:50:57 2018

@author: justinwu
"""

import sqlite3
import os
conn=sqlite3.connect('myreview8.sqlite')
mycur=conn.cursor()
mycur.execute('select * from myreview')
myresults=mycur.fetchall()
conn.close()
print(myresults)
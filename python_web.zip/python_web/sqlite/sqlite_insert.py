#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  9 11:53:55 2018

@author: justinwu
"""

import sqlite3
import os
conn=sqlite3.connect('myreview8.sqlite')
mycur=conn.cursor()
example3='I will like the movie.ok.'
mycur.execute("insert into myreview(review,sentiment,date) values(?,?,DATETIME('now'))",(example3,0))
conn.commit()
conn.close()
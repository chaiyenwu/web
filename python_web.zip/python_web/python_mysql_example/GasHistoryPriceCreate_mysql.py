#!/usr/bin/python3
 
import pymysql
 
#打開資料庫連接
db = pymysql.connect("localhost","root","322739aa","temp" )
 
# 使用cursor()方法得到操作指標 
cursor = db.cursor()
 
# 使用 execute() 方法執行 SQL，如果資料表存在則删除
#cursor.execute("DROP TABLE IF EXISTS HistoryGasPrice")
 
# SQL 語法建立資料表EMPLOYEE
sql = """CREATE TABLE HistoryGasPrice (
         Date  VARCHAR(20) Primary key NOT NULL unique,
         Gas92 DOUBLE NOT NULL,
         Gas95 DOUBLE NOT NULL,  
         Gas98 DOUBLE NOT NULL, 
         GasＷ DOUBLE NOT NULL)"""
 
cursor.execute(sql)
 
# 關閉資料庫連接
db.close()

#!/usr/bin/python3
 
import pymysql
 
#打開資料庫連接
db = pymysql.connect("localhost","root","322739aa","HistoryGasPrice" )
 
# 使用cursor()方法得到操作指標 
cursor = db.cursor()
 
# SQL 語法
sql = "SELECT * FROM HistoryGasPrice"
try:
   # 執行SQL语句
   cursor.execute(sql)
   # 使用 fetchall()得到所有資料
   results = cursor.fetchall()
   for row in results:

      #列印資料
      print ("%s,%6.2f,%6.2f,%6.2f,%6.2f" % \
             (row[0], row[1], row[2], row[3], row[4] ))
except:
   print ("Error: unable to fetch data")
 
# 關閉資料庫連接
db.close()

#!/usr/bin/python3
 
import pymysql
 
#打開資料庫連接
db = pymysql.connect("localhost","root","322739aa","HistoryGasPrice" )
 
# 使用cursor()方法得到操作指標 
cursor = db.cursor()
 
# SQL 語法
sql = "SELECT * FROM EMPLOYEE \
       WHERE INCOME > '%d'" % (1000)
try:
   # 執行SQL语句
   cursor.execute(sql)
   # 使用 fetchall()得到所有資料
   results = cursor.fetchall()
   for row in results:
      fname = row[0]
      lname = row[1]
      age = row[2]
      sex = row[3]
      income = row[4]
      #列印資料
      print ("fname=%s,lname=%s,age=%d,sex=%s,income=%d" % \
             (fname, lname, age, sex, income ))
except:
   print ("Error: unable to fetch data")
 
# 關閉資料庫連接
db.close()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 21:26:57 2018

@author: justinwu
"""

def get_links(url):
    import requests
    from bs4 import BeautifulSoup as soup
    result=requests.get(url)
    page=result.text
    doc=soup(page)
    links=[element.get('href') for element in doc.find_all('a')]
    return links

if __name__ == '__main__':
    import sys
    url='http://www.yahoo.com'
    print('Links in',url)
    for num,link in enumerate(get_links(url),start=1):
        print(num,link)

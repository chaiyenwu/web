#!/usr/bin/python3
 
import pymysql
 
#打開資料庫連接
db = pymysql.connect("localhost","root","322739aa","temp" )
 
# 使用cursor()方法得到操作指標 
cursor = db.cursor()
 
# 使用 execute() 方法執行 SQL，如果資料表存在則删除
cursor.execute("DROP TABLE IF EXISTS EMPLOYEE")
 
# SQL 語法建立資料表EMPLOYEE
sql = """CREATE TABLE EMPLOYEE (
         FIRST_NAME  CHAR(20) NOT NULL,
         LAST_NAME  CHAR(20),
         AGE INT,  
         SEX CHAR(1),
         INCOME FLOAT )"""
 
cursor.execute(sql)
 
# 關閉資料庫連接
db.close()

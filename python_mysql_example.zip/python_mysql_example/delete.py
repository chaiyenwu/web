#!/usr/bin/python3
 
import pymysql
 
#打開資料庫連接
db = pymysql.connect("localhost","root","322739aa","temp" )
 
# 使用cursor()方法得到操作指標 
cursor = db.cursor()
 
# SQL 語法刪除資料
sql = "DELETE FROM EMPLOYEE WHERE AGE > '%d'" % (20)
try:
   # 執行SQL语句
   cursor.execute(sql)
   # 提交到資料庫系統執行
   db.commit()
except:
   # 發生異常錯誤時回復
   db.rollback()
 
# 關閉資料庫連接
db.close()

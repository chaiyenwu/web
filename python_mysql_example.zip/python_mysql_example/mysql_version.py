 
import pymysql
 

#打開資料庫連接
db = pymysql.connect("localhost","root","322739aa","temp" )

# 使用cursor()方法得到操作指標 
cursor = db.cursor()
 
# 執行SQL语句
cursor.execute("SELECT VERSION()")
 
# 使用 fetchone() 方法得到資料
data = cursor.fetchone()
 
print ("Database version : %s " % data)
 
# 關閉資料庫連接
db.close()

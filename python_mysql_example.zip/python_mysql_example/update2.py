#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 23 17:06:37 2017

@author: justinwu
"""

import pymysql


db=pymysql.connect("localhost","root","322739aa","temp")
cursor=db.cursor()
sql = "UPDATE EMPLOYEE SET AGE = AGE + 1 WHERE SEX = '%c'" % ('M')
try:
    
    cursor.execute(sql)
    db.commit()
    
except:
    db.rollback()
    
db.close()
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 15 22:41:22 2017

@author: justinwu
"""

class MyClass2:
    #範例屬性參考
    i=12345
    def f(self):
        return 'hello world'
    
x=MyClass2()
print(x.i)
print(x.f())


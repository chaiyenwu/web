#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 18 21:11:50 2017

@author: justinwu
"""

import pandas as pd
df = pd.read_csv('MI_INDEX.csv',encoding='big5')
print(df.head())
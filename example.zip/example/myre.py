#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 16:43:55 2017

@author: justinwu
"""

def myreturn(x,y):
    return x*y

i3=2
i5=5

i8=myreturn(i3,i5)
print(i8)
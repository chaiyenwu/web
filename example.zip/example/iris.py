#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 17 10:05:38 2017

@author: justinwu
"""

import pandas as pd 
df = pd.read_csv('iris.data')
df.tail()
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 18 16:11:06 2017

@author: justinwu
"""

tp=()
print(tp)
tp2=(1,2,3,4,5,6,7,8)
print(tp2)
print(sum(tp2))
print(tp2[2:5])
print(tp2[-1])
tp6=tuple([1,2,3,4,5,6,7,8])
print(tp6)
list1=list(tp6)
print(list1)

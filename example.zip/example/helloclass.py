#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 17:37:01 2017

@author: justinwu
"""

class MyClass2:
    i=12345
    def f(self):
        return 'hello world'

x=MyClass2()
print(x.f())
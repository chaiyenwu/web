#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 26 10:28:57 2017

@author: justinwu
"""

x=2-3*2
print(x)
y=2-3*2+2/2
print(y)
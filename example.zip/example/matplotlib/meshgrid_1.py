#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 18 12:04:12 2017

@author: justinwu
"""

import numpy as np

#[A,B]=Meshgrid(a,b)
a=[1,2,3,4,5]
b=[1,2,3,4,5]
print(a)
print(b)
print(np.size(b))
A=np.ones(np.size(b))*a;
print(np.size(a))
B=b*np.ones(np.size(a))
print(A)
print(B)

歡迎學習Python深度學習.
此課程分成三個單元,第一單元Python一天學會,第二單元Python 資料結構與畫圖簡介,第三單元Python 類神經網路深度學習.
同學可以進度淺入深逐一學習. 
請幫老師評比五顆星,並且介紹您學到什麼?此課程對您有何幫助?
謝謝。
Justin Wu
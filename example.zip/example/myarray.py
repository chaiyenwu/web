#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 17 11:30:55 2017

@author: justinwu
"""

import pandas as pd

names = ['小寶','小文','阿呆','John','Lin']

myarray = pd.Series(names)

print(myarray)
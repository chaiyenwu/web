#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 18 10:26:04 2017

@author: justinwu
"""
import numpy as np

a = np.zeros((10, 3))
print(a)
print('-----------')
b = a.T
print(b)
print('-------------')
c = np.reshape(b,(5,6))
print(d)
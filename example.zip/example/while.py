#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 11:57:07 2017

@author: justinwu
"""

i=5
while i<=10:
    print("i:",i)
    i=i+1
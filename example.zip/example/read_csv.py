#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 17 09:43:22 2017

@author: justinwu
"""

import pandas as pd 
df = pd.read_csv('MI_INDEX.csv')
df.tail()
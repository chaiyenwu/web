#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 26 14:07:44 2017

@author: justinwu
"""
for i in range(8,19):
    if(i%2==1):
        continue
    print("i的值:",i)
#!/usr/bin/env python3
#_*_coding:utf-8_*_
"""
Created on Thu Oct 26 07:40:42 2017

@author: justinwu
"""
#這是註解

#這是註解
1+2
#print(1+2)
x=2-1
print(x)
y=3+2
print(y)
z=3.2*2
print(z)

str='大家好'
print(str)
str2='Python'
mychar=str[0]
print(mychar)
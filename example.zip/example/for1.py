#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 16:36:21 2017

@author: justinwu
"""

for i in range(8,19):
    print("i:",i)
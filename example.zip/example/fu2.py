#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 16:41:21 2017

@author: justinwu
"""

i = 10
def f():
    print(i)

f()

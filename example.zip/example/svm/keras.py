#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 31 15:29:36 2017

@author: justinwu
"""

import numpy as np 
import pandas as pd
from keras.utils import np_utils
np.random.seed(10)
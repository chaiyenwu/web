#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 16:30:17 2017

@author: justinwu
"""

a = int(input("請輸入薪水:"))
if a < 50000 :
    print("薪水小於50000")
else:
    print("薪水大於50000")